var common_8h =
[
    [ "MKD64_MODULE", "common_8h.html#a433e25abdd06660f982f7d093cbd40e0", null ],
    [ "OBJDEL", "common_8h.html#a174aabfee4f1615324c789a1ebdcfd48", null ],
    [ "OBJNEW", "common_8h.html#a1169b9f46e35832e7dd82764528d1a7e", null ]
];