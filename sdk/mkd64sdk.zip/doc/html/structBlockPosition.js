var structBlockPosition =
[
    [ "sector", "structBlockPosition.html#ab860e0175d7316b3d37b0a234bdc6cca", null ],
    [ "track", "structBlockPosition.html#a3eede3014061f7fa9ca1fe034d13fa7f", null ]
];