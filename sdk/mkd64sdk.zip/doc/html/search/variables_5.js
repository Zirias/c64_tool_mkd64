var searchData=
[
  ['requestreservedblock',['requestReservedBlock',['../structIModule.html#acec38982408c684decd1e0747e4c4ebe',1,'IModule']]]
];
