var searchData=
[
  ['datadelete',['DataDelete',['../classDiskFile.html#acd60086d390a0bbc5fbc7ec4ec271d83',1,'DiskFile']]]
];
