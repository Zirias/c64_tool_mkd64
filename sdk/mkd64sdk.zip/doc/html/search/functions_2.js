var searchData=
[
  ['diskfile_5fattachdata',['DiskFile_attachData',['../classDiskFile.html#ae1c81538884cf3f8124c6dc1b1dac4fe',1,'DiskFile']]],
  ['diskfile_5fblocks',['DiskFile_blocks',['../classDiskFile.html#ae6b136a77fd03ed48170e6f00b2f2a78',1,'DiskFile']]],
  ['diskfile_5fdata',['DiskFile_data',['../classDiskFile.html#a8744993dcc8837dc11b1d76817ee23ca',1,'DiskFile']]],
  ['diskfile_5ffileno',['DiskFile_fileNo',['../classDiskFile.html#a31472946d2aae47f9ca2ca6a1c122d76',1,'DiskFile']]],
  ['diskfile_5finterleave',['DiskFile_interleave',['../classDiskFile.html#a843a27de67251115cc1677d6f0564d79',1,'DiskFile']]],
  ['diskfile_5fname',['DiskFile_name',['../classDiskFile.html#a10a27a04f0c40b7db9a6f3c0cbf9bec0',1,'DiskFile']]],
  ['diskfile_5fsetinterleave',['DiskFile_setInterleave',['../classDiskFile.html#a0ba18d7c196de8dee54d2bed05f47fdd',1,'DiskFile']]],
  ['diskfile_5fsetname',['DiskFile_setName',['../classDiskFile.html#ae4cde814921f061bed393e64136a096e',1,'DiskFile']]],
  ['diskfile_5fsize',['DiskFile_size',['../classDiskFile.html#a84debfbfcc652f60b08faf6b044c2e95',1,'DiskFile']]]
];
