#ifndef MKD64_RANDOM_H
#define MKD64_RANDOM_H

#include <mkd64/common.h>

DECLEXPORT int random_num(int min, int max);

#endif
/* vim: et:si:ts=4:sts=4:sw=4
*/
