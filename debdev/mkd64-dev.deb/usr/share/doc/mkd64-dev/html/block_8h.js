var block_8h =
[
    [ "BlockPosition", "structBlockPosition.html", "structBlockPosition" ],
    [ "BLOCK_RAWSIZE", "block_8h.html#aaedd059949819539b01727ed40c0f450", null ],
    [ "BLOCK_SIZE", "block_8h.html#ad51ded0bbd705f02f73fc60c0b721ced", null ],
    [ "Block", "block_8h.html#a2af45dc93858b3ab0965646789821f60", null ],
    [ "BlockPosition", "block_8h.html#acdacbeeb8f990aa4387aa81f73b851ca", null ],
    [ "BlockStatus", "block_8h.html#a43adb063ba9e8b0f1143146d9c7929d9", [
      [ "BS_NONE", "block_8h.html#a43adb063ba9e8b0f1143146d9c7929d9a2d12b87b8f786ee643522fd75a569ee9", null ],
      [ "BS_ALLOCATED", "block_8h.html#a43adb063ba9e8b0f1143146d9c7929d9afb428bdbf9b058fc0ae1ce7660d03ad7", null ],
      [ "BS_RESERVED", "block_8h.html#a43adb063ba9e8b0f1143146d9c7929d9aec08395356c3e45f07d4c7f91e6644da", null ]
    ] ]
];