var structIBlockAllocator =
[
    [ "allocFirstBlock", "structIBlockAllocator.html#ada68f2a088df421514a7df1c07959334", null ],
    [ "allocNextBlock", "structIBlockAllocator.html#afd0bbc86c8102e4a72da91739a4adc36", null ],
    [ "setConsiderReserved", "structIBlockAllocator.html#ada7888d422e313f043deb4ab48ed247b", null ],
    [ "setImage", "structIBlockAllocator.html#a56367d6c4807341f13f24b4959e03082", null ],
    [ "setInterleave", "structIBlockAllocator.html#a04b789dcc9fb53519bbab9f25268a340", null ]
];