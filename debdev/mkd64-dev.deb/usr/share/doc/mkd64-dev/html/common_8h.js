var common_8h =
[
    [ "API_VER_BETA", "common_8h.html#a89149551205a8feb774fae9c59f56355", null ],
    [ "API_VER_MAJOR", "common_8h.html#aa9bdd82c2c6de0f60c8194dfa1dae106", null ],
    [ "API_VER_MINOR", "common_8h.html#a8c781bba8661cde9a3ef63a54c8cc405", null ],
    [ "DECLEXPORT", "common_8h.html#a0a24ae616e6fb90fea32a6b949e6cbce", null ],
    [ "mkd64___cdecl", "common_8h.html#ab35c184ad204b4513150e7897c760543", null ],
    [ "MKD64_MODULE", "common_8h.html#a433e25abdd06660f982f7d093cbd40e0", null ],
    [ "OBJDEL", "common_8h.html#a174aabfee4f1615324c789a1ebdcfd48", null ],
    [ "OBJNEW", "common_8h.html#a1169b9f46e35832e7dd82764528d1a7e", null ],
    [ "OBJNEW1", "common_8h.html#a851c4bc02e5cf176a70ced0954305117", null ],
    [ "OBJNEW2", "common_8h.html#ade9d0e7ad9196b33b7b8e256ac014afb", null ],
    [ "OBJNEW3", "common_8h.html#a847997082cd802b6ce4b9eda4f15c306", null ],
    [ "OBJNEW4", "common_8h.html#a5cd3241e0cfb92cdf712d7776c0616ba", null ],
    [ "OBJNEW5", "common_8h.html#a2d56b0ea22a992f22f93c60aa13c6762", null ],
    [ "SOEXPORT", "common_8h.html#ab749467aa1c65db8b468d947709f8a48", null ],
    [ "SOLOCAL", "common_8h.html#a08ea6a2d67bb172293cc2e9b74b3603d", null ],
    [ "uint8_t", "common_8h.html#aba7bc1797add20fe3efdf37ced1182c5", null ],
    [ "uintptr_t", "common_8h.html#a728e973c799f206f0151c8a3bd1e5699", null ]
];