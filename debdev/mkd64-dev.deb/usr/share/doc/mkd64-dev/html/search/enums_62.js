var searchData=
[
  ['blockstatus',['BlockStatus',['../block_8h.html#a43adb063ba9e8b0f1143146d9c7929d9',1,'block.h']]]
];
