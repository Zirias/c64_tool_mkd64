var searchData=
[
  ['sector',['sector',['../structBlockPosition.html#ab860e0175d7316b3d37b0a234bdc6cca',1,'BlockPosition']]],
  ['setconsiderreserved',['setConsiderReserved',['../structIBlockAllocator.html#ada7888d422e313f043deb4ab48ed247b',1,'IBlockAllocator']]],
  ['setimage',['setImage',['../structIBlockAllocator.html#a56367d6c4807341f13f24b4959e03082',1,'IBlockAllocator']]],
  ['setinterleave',['setInterleave',['../structIBlockAllocator.html#a04b789dcc9fb53519bbab9f25268a340',1,'IBlockAllocator']]],
  ['statuschanged',['statusChanged',['../structIModule.html#a7042ff8abdab3d998dc98b4710e88131',1,'IModule']]]
];
