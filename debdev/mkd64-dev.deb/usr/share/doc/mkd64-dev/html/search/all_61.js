var searchData=
[
  ['allocfirstblock',['allocFirstBlock',['../structIBlockAllocator.html#ada68f2a088df421514a7df1c07959334',1,'IBlockAllocator']]],
  ['allocnextblock',['allocNextBlock',['../structIBlockAllocator.html#afd0bbc86c8102e4a72da91739a4adc36',1,'IBlockAllocator']]]
];
