var searchData=
[
  ['bs_5fallocated',['BS_ALLOCATED',['../block_8h.html#a43adb063ba9e8b0f1143146d9c7929d9afb428bdbf9b058fc0ae1ce7660d03ad7',1,'block.h']]],
  ['bs_5fnone',['BS_NONE',['../block_8h.html#a43adb063ba9e8b0f1143146d9c7929d9a2d12b87b8f786ee643522fd75a569ee9',1,'block.h']]],
  ['bs_5freserved',['BS_RESERVED',['../block_8h.html#a43adb063ba9e8b0f1143146d9c7929d9aec08395356c3e45f07d4c7f91e6644da',1,'block.h']]]
];
