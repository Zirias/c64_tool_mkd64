var searchData=
[
  ['block_5frawsize',['BLOCK_RAWSIZE',['../block_8h.html#aaedd059949819539b01727ed40c0f450',1,'block.h']]],
  ['block_5fsize',['BLOCK_SIZE',['../block_8h.html#ad51ded0bbd705f02f73fc60c0b721ced',1,'block.h']]]
];
