var searchData=
[
  ['objdel',['OBJDEL',['../common_8h.html#a174aabfee4f1615324c789a1ebdcfd48',1,'common.h']]],
  ['objnew',['OBJNEW',['../common_8h.html#a1169b9f46e35832e7dd82764528d1a7e',1,'common.h']]]
];
